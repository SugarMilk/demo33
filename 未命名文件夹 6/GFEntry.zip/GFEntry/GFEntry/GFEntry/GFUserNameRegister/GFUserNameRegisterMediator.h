//
//  GFUserNameRegisterMediator.h
//  GFEntry
//
//  Created by huangjian on 17/3/21.
//  Copyright © 2017年 huangjian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface GFUserNameRegisterMediator : NSObject

+ (void)openEntrance:(UIViewController *)viewController;

@end
