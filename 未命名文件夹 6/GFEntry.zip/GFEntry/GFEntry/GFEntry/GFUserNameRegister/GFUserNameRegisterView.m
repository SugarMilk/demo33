//
//  GFUserNameRegisterView.m
//  GFEntry
//
//  Created by huangjian on 17/3/21.
//  Copyright © 2017年 huangjian. All rights reserved.
//

#import "GFUserNameRegisterView.h"
#import <GFUtil/GFTextField.h>
#import <Masonry/Masonry.h>

@interface GFUserNameRegisterView ()

@property (nonatomic, strong) GFTextFieldView * usernameTextFieldView;
@property (nonatomic, strong) GFTextFieldView * passwordTextFieldView;
@property (nonatomic, strong) UIButton * registerButton;
@property (nonatomic, strong) UIButton * agreementButton;
@property (nonatomic, strong) UILabel * usernameTipLabel;
@property (nonatomic, strong) UILabel * passwordTipLabel;

@property (nonatomic, copy) GFUserNameRegisterViewButtonActionBlock buttonActionBlock;

@end

@implementation GFUserNameRegisterView

- (instancetype)init {
    if (self = [super init]) {
        [self addSubview:self.usernameTextFieldView];
        [self addSubview:self.passwordTextFieldView];
        [self addSubview:self.registerButton];
        [self addSubview:self.agreementButton];
        [self addSubview:self.usernameTipLabel];
        [self addSubview:self.passwordTipLabel];
    }
    return self;
}

- (void)setUsername:(NSString *)username {
    self.usernameTextFieldView.textField.text = username;
}

- (NSString *)username {
    return self.usernameTextFieldView.textField.text;
}

- (void)setPassword:(NSString *)password {
    self.passwordTextFieldView.textField.text = password;
}

- (NSString *)password {
    return self.passwordTextFieldView.textField.text;
}

- (void)handleButtonActionBlock:(GFUserNameRegisterViewButtonActionBlock)buttonActionBlock {
    self.buttonActionBlock = buttonActionBlock;
}

- (void)registerButtonAction:(UIButton *)button {
    if (self.buttonActionBlock) {
        self.buttonActionBlock(button, GFUserNameRegisterViewButtonTypeRegister);
    }
}

- (void)agreementButtonAction:(UIButton *)button {
    if (self.buttonActionBlock) {
        self.buttonActionBlock(button, GFUserNameRegisterViewButtonTypeAgreement);
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.usernameTextFieldView.textField.backgroundColor = [UIColor whiteColor];
    self.passwordTextFieldView.textField.backgroundColor = [UIColor whiteColor];
    self.registerButton.backgroundColor = [UIColor purpleColor];
    self.agreementButton.backgroundColor = [UIColor orangeColor];
    self.usernameTipLabel.backgroundColor = [UIColor colorWithWhite:0.2 alpha:0.8];
    self.passwordTipLabel.backgroundColor = [UIColor colorWithWhite:0.2 alpha:0.8];
    
    CGFloat height = 35;
    
    [self.usernameTextFieldView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self).with.insets(UIEdgeInsetsMake(30, 10, 0, 10));
        make.height.mas_equalTo(height);
    }];
    
    [self.passwordTextFieldView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.usernameTextFieldView.mas_bottom).with.offset(15);
        make.left.right.equalTo(self.usernameTextFieldView);
        make.height.mas_equalTo(height);
    }];
    
    [self.registerButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.passwordTextFieldView.mas_bottom).with.offset(15);
        make.left.right.equalTo(self.passwordTextFieldView);
        make.height.mas_equalTo(35);
    }];
    
    [self.usernameTipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.usernameTextFieldView.mas_bottom);
        make.left.right.equalTo(self.usernameTextFieldView);
        make.height.mas_equalTo(13);
    }];
    
    [self.passwordTipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.passwordTextFieldView.mas_bottom);
        make.left.right.equalTo(self.passwordTextFieldView);
        make.height.mas_equalTo(13);
    }];
    
    [self.agreementButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.registerButton.mas_bottom).with.offset(5);
        make.centerX.equalTo(self.mas_centerX);
        make.size.mas_equalTo(CGSizeMake(100, 20));
    }];
}

- (GFTextFieldView *)usernameTextFieldView {
    if (_usernameTextFieldView == nil) {
        _usernameTextFieldView = [[GFTextFieldView alloc] init];
    }
    return _usernameTextFieldView;
}

- (GFTextFieldView *)passwordTextFieldView {
    if (_passwordTextFieldView == nil) {
        _passwordTextFieldView = [[GFTextFieldView alloc] init];
    }
    return _passwordTextFieldView;
}

- (UIButton *)registerButton {
    if (_registerButton == nil) {
        _registerButton = [[UIButton alloc] init];
        [_registerButton addTarget:self action:@selector(registerButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _registerButton;
}

- (UIButton *)agreementButton {
    if (_agreementButton == nil) {
        _agreementButton = [[UIButton alloc] init];
        [_agreementButton addTarget:self action:@selector(agreementButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _agreementButton;
}

- (UILabel *)usernameTipLabel {
    if (_usernameTipLabel == nil) {
        _usernameTipLabel = [[UILabel alloc] init];
    }
    return _usernameTipLabel;
}

- (UILabel *)passwordTipLabel {
    if (_passwordTipLabel == nil) {
        _passwordTipLabel = [[UILabel alloc] init];
    }
    return _passwordTipLabel;
}

@end
