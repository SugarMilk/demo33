
//
//  GFUserNameLoginView.m
//  GFEntry
//
//  Created by huangjian on 17/3/21.
//  Copyright © 2017年 huangjian. All rights reserved.
//

#import "GFUserNameLoginView.h"
#import <GFUtil/GFTextField.h>
#import <Masonry/Masonry.h>

@interface GFUserNameLoginView ()

@property (nonatomic, strong) GFTextFieldView * usernameTextFieldView;
@property (nonatomic, strong) GFTextFieldView * passwordTextFieldView;
@property (nonatomic, strong) UIButton * forgotPasswordButton;
@property (nonatomic, strong) UIButton * loginButton;

@property (nonatomic, copy) GFUserNameLoginViewButtonActionBlock buttonActionBlock;

@end


@implementation GFUserNameLoginView

- (instancetype)init {
    if (self = [super init]) {
        [self addSubview:self.usernameTextFieldView];
        [self addSubview:self.passwordTextFieldView];
        [self addSubview:self.forgotPasswordButton];
        [self addSubview:self.loginButton];
    }
    return self;
}

- (void)setUsername:(NSString *)username {
    self.usernameTextFieldView.textField.text = username;
}

- (NSString *)username {
    return self.usernameTextFieldView.textField.text;
}

- (void)setPassword:(NSString *)password {
    self.passwordTextFieldView.textField.text = password;
}

- (NSString *)password {
    return self.passwordTextFieldView.textField.text;
}

- (void)handleButtonActionBlock:(GFUserNameLoginViewButtonActionBlock)buttonActionBlock {
    self.buttonActionBlock = buttonActionBlock;
}

- (void)forgotPasswordButtonAction:(UIButton *)button {
    if (self.buttonActionBlock) {
        self.buttonActionBlock(button, GFUserNameLoginViewButtonTypeForgotPassword);
    }
}

- (void)loginButtonAction:(UIButton *)button {
    if (self.buttonActionBlock) {
        self.buttonActionBlock(button, GFUserNameLoginViewButtonTypeLogin);
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.usernameTextFieldView.textField.backgroundColor = [UIColor whiteColor];
    self.passwordTextFieldView.textField.backgroundColor = [UIColor whiteColor];
    self.forgotPasswordButton.backgroundColor = [UIColor orangeColor];
    self.loginButton.backgroundColor = [UIColor purpleColor];
    
    CGFloat height = 35;
    
    [self.usernameTextFieldView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self).with.insets(UIEdgeInsetsMake(30, 10, 0, 10));
        make.height.mas_equalTo(height);
    }];
    
    [self.passwordTextFieldView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.usernameTextFieldView.mas_bottom).with.offset(15);
        make.left.right.equalTo(self.usernameTextFieldView);
        make.height.mas_equalTo(height);
    }];
    
    [self.forgotPasswordButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.passwordTextFieldView.mas_bottom).with.offset(10);
        make.right.equalTo(self.passwordTextFieldView.mas_right);
        make.size.mas_equalTo(CGSizeMake(100, 20));
    }];
    
    [self.loginButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.forgotPasswordButton.mas_bottom).with.offset(15);
        make.left.right.equalTo(self.passwordTextFieldView);
        make.height.mas_equalTo(35);
    }];
}

- (GFTextFieldView *)usernameTextFieldView {
    if (_usernameTextFieldView == nil) {
        _usernameTextFieldView = [[GFTextFieldView alloc] init];
    }
    return _usernameTextFieldView;
}

- (GFTextFieldView *)passwordTextFieldView {
    if (_passwordTextFieldView == nil) {
        _passwordTextFieldView = [[GFTextFieldView alloc] init];
    }
    return _passwordTextFieldView;
}

- (UIButton *)forgotPasswordButton {
    if (_forgotPasswordButton == nil) {
        _forgotPasswordButton = [[UIButton alloc] init];
        [_forgotPasswordButton addTarget:self action:@selector(forgotPasswordButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _forgotPasswordButton;
}

- (UIButton *)loginButton {
    if (_loginButton == nil) {
        _loginButton = [[UIButton alloc] init];
        [_loginButton addTarget:self action:@selector(loginButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _loginButton;
}

@end
