//
//  GFAgreementViewController.h
//  GFEntry
//
//  Created by huangjian on 17/3/22.
//  Copyright © 2017年 huangjian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GFBasePopViewController.h"

// 用户协议与验证码收不到共用一个控制器

@interface GFAgreementViewController : GFBasePopViewController



@end
