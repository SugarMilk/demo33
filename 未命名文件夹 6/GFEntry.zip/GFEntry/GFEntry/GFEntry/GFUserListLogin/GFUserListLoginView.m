//
//  GFUserListLoginView.m
//  GFEntry
//
//  Created by huangjian on 17/3/22.
//  Copyright © 2017年 huangjian. All rights reserved.
//

#import "GFUserListLoginView.h"
#import <GFUtil/GFTextField.h>
#import <Masonry/Masonry.h>
#import "GFUserListLoginPopView.h"

@interface GFUserListLoginView ()

@property (nonatomic, strong) GFTextFieldView * usernameTextFieldView;
@property (nonatomic, strong) UIButton * loginButton;
@property (nonatomic, strong) UIImageView * lineImageView;
@property (nonatomic, strong) UIButton * switchAccountButton;
@property (nonatomic, strong) GFUserListLoginPopView * popView;
@property (nonatomic, retain) NSMutableArray * dataSource;

@property (nonatomic, copy) GFUserListLoginViewButtonActionBlock buttonActionBlock;

@end

@implementation GFUserListLoginView

- (instancetype)init {
    if (self = [super init]) {
        [self addSubview:self.usernameTextFieldView];
        [self addSubview:self.loginButton];
        [self addSubview:self.lineImageView];
        [self addSubview:self.switchAccountButton];
        [self addSubview:self.popView];
    }
    return self;
}

- (void)setDataSourceArray:(NSArray *)array {
    self.dataSource = [NSMutableArray arrayWithArray:array];
}

- (void)handleButtonActionBlock:(GFUserListLoginViewButtonActionBlock)buttonActionBlock {
    self.buttonActionBlock = buttonActionBlock;
}

- (void)loginButtonAction:(UIButton *)button {
    if (self.buttonActionBlock) {
#warning 用户列表登录回调内容
        self.buttonActionBlock(nil, GFUserListLoginViewButtonTypeLogin);
    }
}

- (void)switchAccountButtonAction:(UIButton *)button {
    if (self.buttonActionBlock) {
        self.buttonActionBlock(button, GFUserListLoginViewButtonTypeSwitchAccount);
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.usernameTextFieldView.textField.backgroundColor = [UIColor whiteColor];
    self.loginButton.backgroundColor = [UIColor purpleColor];
    self.lineImageView.backgroundColor = [UIColor grayColor];
    self.switchAccountButton.backgroundColor = [UIColor blueColor];
    self.popView.backgroundColor = [UIColor orangeColor];
    
    self.usernameTextFieldView.rightButton.backgroundColor = [UIColor orangeColor];
    [self.usernameTextFieldView addWithButtonType:GFTextFieldButtonTypeRight width:60];
    
    CGFloat height = 35;
    
    [self.usernameTextFieldView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self).with.insets(UIEdgeInsetsMake(40, 10, 0, 10));
        make.height.mas_equalTo(height);
    }];
    
    [self.loginButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.usernameTextFieldView.mas_bottom).with.offset(20);
        make.left.right.equalTo(self.usernameTextFieldView);
        make.height.mas_equalTo(35);
    }];
    
    [self.lineImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.loginButton.mas_bottom).with.offset(30);
        make.left.and.right.equalTo(self.usernameTextFieldView).with.insets(UIEdgeInsetsMake(0, 10, 0, 10));
        make.height.mas_equalTo(5);
    }];
    
    [self.switchAccountButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.lineImageView.mas_bottom).with.offset(5);
        make.centerX.equalTo(self.mas_centerX);
        make.size.mas_equalTo(CGSizeMake(100, 25));
    }];
    
    [self.popView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.usernameTextFieldView.mas_bottom).with.offset(2);
        make.left.and.right.equalTo(self.usernameTextFieldView);
        make.height.mas_equalTo(100);
    }];
}

- (GFTextFieldView *)usernameTextFieldView {
    if (_usernameTextFieldView == nil) {
        _usernameTextFieldView = [[GFTextFieldView alloc] init];
        [_usernameTextFieldView addWithButtonType:GFTextFieldButtonTypeLeft width:50];
        _usernameTextFieldView.leftButton.backgroundColor = [UIColor redColor];
    }
    return _usernameTextFieldView;
}

- (UIButton *)loginButton {
    if (_loginButton == nil) {
        _loginButton = [[UIButton alloc] init];
        [_loginButton addTarget:self action:@selector(loginButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _loginButton;
}

- (UIButton *)switchAccountButton {
    if (_switchAccountButton == nil) {
        _switchAccountButton = [[UIButton alloc] init];
        [_switchAccountButton addTarget:self action:@selector(switchAccountButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _switchAccountButton;
}

- (UIImageView *)lineImageView {
    if (_lineImageView == nil) {
        _lineImageView = [[UIImageView alloc] init];
    }
    return _lineImageView;
}

- (GFUserListLoginPopView *)popView {
    if (_popView == nil) {
        _popView = [[GFUserListLoginPopView alloc] init];
        _popView.hidden = YES;
        [_popView handlePopViewActionBlock:^BOOL(NSIndexPath *indexPath, GFUserListLoginPopViewActionType actionType) {
#warning 用户列表移除回调内容
            if (actionType == GFUserListLoginPopViewActionTypeRemove) {
                if (self.buttonActionBlock) {
                    if (self.buttonActionBlock(nil, GFUserListLoginViewButtonTypeRemove)) {
                        return YES;
                    }
                }
            } else if (actionType == GFUserListLoginPopViewActionTypeSelect) {
                return YES;
            }
            return NO;
        }];
    }
    return _popView;
}

@end
