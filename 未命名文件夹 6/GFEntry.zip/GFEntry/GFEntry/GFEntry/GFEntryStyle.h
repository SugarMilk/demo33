//
//  GFEntryStyle.h
//  GFEntry
//
//  Created by huangjian on 17/3/20.
//  Copyright © 2017年 huangjian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <GFUtil/UIColor+GFHex.h>

FOUNDATION_EXPORT id GFEntryStyle(NSString * identifier);
